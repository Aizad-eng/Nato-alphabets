import pandas
nato_file = pandas.read_csv("nato_phonetic_alphabet.csv")
dict  = {row.letter: row.code for (index, row) in nato_file.iterrows() }
word = input("what is your word?")
list = [*word]
new_list = [item.upper() for item in list]
coded_list = []

c = [value for item in new_list for key, value in dict.items() if key==item]
# for item in new_list:
#     for (key, value) in dict.items():
#         if key == item:
#             coded_list.append(value)
print(c)